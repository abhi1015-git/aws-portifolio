# AWS-Portfolio-cicd
This repository contains the CI/CD pipeline for deploying a static AWS portfolio website using Amazon S3 and GitHub Actions.

# Architecture Diagram

![image](https://github.com/user-attachments/assets/4c26a75b-e11f-4047-a414-f658c349467d)

